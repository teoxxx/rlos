RLOS version 1.15.1. 

This is  Relativistic Line Of Sight, released under the LGPL-3.0-or-later licence, a program that produces synthetic, time-delayed images of model relativistic astrophysical systems. It crosses with parallel lines of sight the model system, resulting to a synthetic image. The geometry of the model system may be either input manually, for simpler geometries that are steady-state. Or RLOS may run on the data output of a time-dependent hydrocode, which is the case in this version of the software. More specifically, RLOS is optimized to run on the results of PLUTO, written by A. Mignone and his team. There are currently two main source code files in RLOS, for imaging on two different planes, called XZ and YZ respectively.


How to run:

In order to run the program, IDL or GDL should be already installed. 

I. First of all, please put (1) RLOS itself, (2) parameter file rlos_params.txt, (3) PLUTO's data output, IN .dbl FORMAT (including all the big and little files of the hydrocode run), and also (4) PLUTO's accompanying IDL routines (found in the PLUTO distro, under '..../PLUTO/tools/IDL/' subdir) IN THE SAME DIRECTORY. 

A simple way to do the above is to first run PLUTO, with .dbl data output, and then paste into the directory of the results the following: RLOS, its param file rlos_param.txt, and PLUTO's IDL routines.

II. Then we open RLOS and EDIT THE PATH NEAR THE BEGINNING, called datapath. We set the name of the path to: the directory of PLUTO data and RLOS. Therefore: Set, within RLOS, datapath='....', where .... is the filesystem location of RLOS, PLUTO's data output, PLUTO's IDL routines and rlos_params.txt.

III. Then please execute the first few lines of RLOS, in order to call and execute pload.pro at least once. This is a requirement of that routine, which comes with PLUTO and loads hydrocode data. Those lines should look similar to the following: (datapath should be changed to your own location of PLUTO data, etc)

;*************************************** 
DATAPATH='Q:\gitstuff\tempy210818SMALL'
cd, datapath
GDL_DIR='C:\Program Files (x86)\gnudatalanguage\gdlde'
PATH=!PATH+'C:\Program Files (x86)\gnudatalanguage\gdlde\'
!PATH=!PATH+datapath
pload, 1, dir=datapath
;***************************************

IV. Please edit the parameter file rlos_params.txt in order to setup RLOS for the run. At first, this might not be necessary, if you are running a ready--made example dataset.

V. Please compile RLOS and then run it. The synthetic image should emerge at the end of the execution. 

*******************************************************************************************

rlos_params.txt

The contents of the parameter file are briefly explained here. For more physical details, please see the relevant scientific paper of RLOS.

 
datapath (filesystem location of both hydro data and rlos) Entry IS INERT AT THE MOMENT!    
'Q:\gitstuff\tempy210818SMALL'
conditional_stop (0=NO, 1=YES: use stops along the execution line) 
0
debug_comments (0=NO, 1=YES: show debug interim results during execution)
0
sfactor_external (pload's shrink factor: please see pload.pro for more on this)
1.0
speedtweakfactor_external (ts speadtweak factor, please see paper)
1.0
clight_override_external (0=NO natural clight value, 1=YES: override clight using clight preset value) 
0
clight_preset_external (clight override value)
0.1
jet_norm_velocity_external jet nomial speed, as set in PLUTO.
0.8
shotmin_external MINIMUM snapshot to be loaded to RLOS
2
shotmax_external MAXIMUM snapshot to be loaded to RLOS
22
phi2_external ANGLE 2
0.05D
phi1_external ANGLE 1
1.57D
freqshiftchoice_external FS SWITCH, 0 is off, 1 is on. See paper for details.
0
dopplerchoice_external DB switch, 0 is off, 1 is on. See paper for details. 
1.0
alphaindex_external The spectral index of the presumed spectrum for the imaged jet system.
2.0
nobs_external Observing frequency. This is not used for now, since only density causes emission
8000000000.0
NLONG_external  technical parameter, max resolution. PLese set to a higher value than the grid largest length size.
150.0
plutolength_external: length dimension
10000000000
plutospeed_external: speed dimension
30000000000
plutodensity_external: density dimension
0.00000000000000000000000167
plutocelllength_external: again length dimension
10000000000


*******************************************************************************************

Troubleshooting.

1. Please do not try to load more snapshots than available in the data. In rlos_params.txt, shotmin and shotmax correspond to the first and last snapshot respectively, as loaded by RLOS to RAM, and THEY SHOULD BE THERE in the hydro-data!

2. phi1 and phi2 angles are meant to vary from 0 to 90 degrees, or from zero to about 1.57 rads. In RLOS they are expressed in RADIANS, so angles vary from 0 to 1.57... rads. 

3. The combination of parameters in rlos_params.txt should correspond to a physically realistic setup. For example, they should NOT produce velocities higher than c, such as when ts=10 and ujet(injected)=0.25c. 

3. The considerable power of IDL/GDL can be used to improve the presentation and even production of results, but care should be exercised when editing RLOS, in order to not disturb the correct execution of the program. 
